import subprocess
import os

# Correr Multiwfn para cada archivo de entrada
for i in range(1, 20):
    input_file = f"{i}tddft.gbw"
    output_file = f"{i}NO_0001.mwfn"

    # Ejecutar Multiwfn
    command = f"Multiwfn {input_file}"
    process = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)

    # Simular la interacción con Multiwfn
    process.stdin.write("18\n")
    process.stdin.write("13\n")
    process.stdin.write("\n")  # Presionar Enter
    process.stdin.write("1\n")
    process.stdin.write("q\n")  # Salir del programa
    process.communicate()  # Esperar a que el proceso termine

    # Cambiar el nombre del archivo resultante
    os.rename("NO_0001.mwfn", output_file)
