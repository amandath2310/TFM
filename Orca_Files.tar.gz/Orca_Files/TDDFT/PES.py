import os
import csv

def extract_energy(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if "<Energy = T + Vne + Vee + Vnn>" in line:
                energy_line = lines[i+1]
                energy = float(energy_line.strip())
                return energy

#Creating the csv file
with open('wB97X_PES.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Distance', 'wB97X-energy'])

    #Iteration in the mwfn files
    for i in range(1,20):
        file_path = f"{i}tddft.wfx"
        distance = (i+1) * 0.2

        #Extracting energy values
        energy = extract_energy(file_path)

        #Write the values in the csv file
        writer.writerow([distance, energy])
