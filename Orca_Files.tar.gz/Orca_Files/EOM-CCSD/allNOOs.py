import os
import csv

def extract_occupancy(file_path):
    with open(file_path, 'r') as f:
        found_start = False
        occupancies = []
        for line in f:
            if found_start:
                if "Natural Orbital Occupation Numbers:" in line:
                    occupancies =[]
                    for j in range(28):
                        occupancy_line = next(f).strip().split('=')[1]
                        occupancies.append(float(occupancy_line))
                    return occupancies
                    break
            elif "density matrix for EE states 1" in line:
                found_start = True
        return occupancies 

#Creating the csv file
with open('all_EOM.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Distance'] + [f'Occ{i+1}' for i in range(28)])

    #Iteration in the output files
    for i in range(1,20):
        file_path = f"{i}eom.out"
        distance = (i+1) * 0.2

        #Extracting occupancy values
        occupancies = extract_occupancy(file_path)

        #Write the values in the csv file
        writer.writerow([distance] + occupancies)
