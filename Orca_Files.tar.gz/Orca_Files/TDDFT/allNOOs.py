import os
import csv

#Extracting the occupation numbers from the mwfn files
def extract_occupancy(file_path):
    occupancies = []
    with open(file_path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            if line.startswith('Occ='):
                occupancy = float(line.split('=')[1].strip())
                occupancies.append(occupancy)
    return occupancies

#Creating the csv file
with open('all_wB97X.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Distance'] + [f'Occ{i+1}' for i in range(10)])

    #Iteration in the mwfn files
    for i in range(1,20):
        file_path = f"{i}NO_0001.mwfn"
        distance = (i+1) * 0.2

        #Extracting occupancy values
        occupancies = extract_occupancy(file_path)

        #Making sure I just saving the 10 values of NOOs
        if len(occupancies) !=10:
            raise ValueError(f'Incorrect numbers of occupations in {file_path}')

        #Write the values in the csv file
        writer.writerow([distance] + occupancies)
